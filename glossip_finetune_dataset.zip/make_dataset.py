"""Build train.jsonl / val.jsonl / test.jsonl from a project folder.

Usage:  python make_dataset.py glossip_message_classifier
Reads   <folder>/system_prompt.txt and <folder>/examples.csv (columns: input, output)
Writes  <folder>/train.jsonl, val.jsonl, test.jsonl   (80 / 10 / 10, split per label, fixed seed)
Each line:  {"messages": [system, user, assistant]}
"""
import csv, json, random, sys
from collections import defaultdict
from pathlib import Path

folder = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
system = (folder / "system_prompt.txt").read_text(encoding="utf-8").strip()
with open(folder / "examples.csv", newline="", encoding="utf-8") as f:
    rows = [(r["input"].strip(), r["output"].strip()) for r in csv.DictReader(f)]

by_label = defaultdict(list)
for text, label in rows:
    by_label[label].append((text, label))

rng = random.Random(42)
train, val, test = [], [], []
for label in sorted(by_label):
    items = by_label[label]
    rng.shuffle(items)
    n = len(items)
    n_test = max(1, round(n * 0.10))
    n_val = max(1, round(n * 0.10))
    test += items[:n_test]
    val += items[n_test:n_test + n_val]
    train += items[n_test + n_val:]

def write(name, items):
    rng.shuffle(items)
    with open(folder / name, "w", encoding="utf-8") as f:
        for text, label in items:
            line = {"messages": [{"role": "system", "content": system},
                                 {"role": "user", "content": text},
                                 {"role": "assistant", "content": label}]}
            f.write(json.dumps(line, ensure_ascii=False) + "\n")

write("train.jsonl", train); write("val.jsonl", val); write("test.jsonl", test)
print(f"train {len(train)}, val {len(val)}, test {len(test)}  (total {len(rows)})")
