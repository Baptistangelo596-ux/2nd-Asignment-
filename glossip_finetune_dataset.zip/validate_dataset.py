"""Check a project folder.  Usage:  python validate_dataset.py glossip_message_classifier"""
import csv, json, re, sys
from collections import Counter
from pathlib import Path

folder = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
errors, warnings = [], []
system = (folder / "system_prompt.txt").read_text(encoding="utf-8").strip() if (folder / "system_prompt.txt").exists() else ""
if not system: errors.append("system_prompt.txt is missing or empty")
with open(folder / "examples.csv", newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    if reader.fieldnames != ["input", "output"]: errors.append(f"columns must be input,output - found {reader.fieldnames}")
    rows = [(r["input"].strip(), r["output"].strip()) for r in reader]

n = len(rows)
if n < 100: errors.append(f"only {n} examples, need at least 100")
labels = Counter(o for _, o in rows)
allowed = set(re.findall(r"(\w+) \(", system)) if system else set()
for i, (t, o) in enumerate(rows, 2):
    if not t: errors.append(f"row {i}: empty input")
    if not o: errors.append(f"row {i}: empty output")
    if allowed and o not in allowed: errors.append(f"row {i}: label '{o}' is not in the system prompt")
    if o.lower().startswith(("sure", "here is", "the label")): errors.append(f"row {i}: output has chatter")
    if len(t) > 300: warnings.append(f"row {i}: very long input ({len(t)} chars)")
dups = [t for t, c in Counter(t.lower() for t, _ in rows).items() if c > 1]
for t in dups: errors.append(f"duplicate input: {t}")
if labels and max(labels.values()) > 3 * min(labels.values()):
    errors.append(f"labels unbalanced: {dict(labels)}")
roman = sum(bool(re.search(r"\b(hai|kya|mujhe|kar|ka|ki|ke|nahi|aap|main)\b", t.lower())) for t, _ in rows)
if roman < 0.3 * n: warnings.append("less than 30% of examples look like Roman Urdu")
print(f"examples: {n}\nlabels: {dict(labels)}\nRoman Urdu-looking inputs: {roman}")

splits = {}
for name in ("train", "val", "test"):
    p = folder / f"{name}.jsonl"
    if not p.exists(): warnings.append(f"{name}.jsonl not built yet (run make_dataset.py)"); continue
    items = [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]
    splits[name] = {it["messages"][1]["content"].lower() for it in items}
    for it in items:
        m = it["messages"]
        if [x["role"] for x in m] != ["system", "user", "assistant"]: errors.append(f"{name}: wrong message roles")
        if m[0]["content"] != system: errors.append(f"{name}: system prompt differs from system_prompt.txt")
    print(f"{name}.jsonl: {len(items)} lines, labels {dict(Counter(it['messages'][2]['content'] for it in items))}")
for a, b in (("train", "val"), ("train", "test"), ("val", "test")):
    if a in splits and b in splits and splits[a] & splits[b]: errors.append(f"{a} and {b} share examples (leak)")

for w in warnings: print("WARNING:", w)
for e in errors: print("ERROR:", e)
print("RESULT:", "FAILED" if errors else "OK - no errors")
sys.exit(1 if errors else 0)
