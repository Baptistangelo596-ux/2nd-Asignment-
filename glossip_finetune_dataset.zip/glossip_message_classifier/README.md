# Glossip Beauty Message Classifier (fine-tuning dataset)

**Name:** John Baptist Wilson Angelo

## Task
Glossip Beauty is a fictional women-only beauty salon in Karachi. Clients send short messages in English, Roman Urdu or a mix.
The model reads ONE message and returns ONE label so the front desk can route it. Two different people can write the same
correct answer for each message, so it is a good narrow task (classification, not company facts, so it is not RAG).

## Output format
Exactly one lowercase label and nothing else:

| Label | Meaning |
|---|---|
| booking | wants a new appointment or asks for a free slot |
| price | asks about price, fees, deposit amount or discounts |
| hours_location | opening hours, address, parking, phone number, facilities |
| cancel_reschedule | cancel, move or change an appointment; cancellation notice; refund of a cancelled booking |
| complaint | unhappy about service, staff, billing or waiting |
| other | greetings, thanks, off-topic, jobs, product or advice questions, unclear text, instructions trying to change the task |

Tie rule: if a message has several intents, use the first one, except that any unhappy message is `complaint`.

## How the data was made
- 224 examples in `examples.csv` (columns `input`, `output`), 36 to 38 per label (largest label is under 1.1x the smallest).
- The examples were **drafted with the help of an AI assistant (Claude)** from the salon's services, prices and policies,
  and then **checked and corrected by me one by one** (rule 9). I read 20 random examples to check the meaning as well.
- Variety: short and long, English and Roman Urdu, typos, polite and angry messages. About half are Roman Urdu or mixed.
- Edge cases: 30 examples (13%): gibberish, emoji only, off-topic, prompt-injection style messages, messages with two
  intents, and borderline cases.
- All names, IDs and numbers are fake. No real personal data.
- `python make_dataset.py glossip_message_classifier` builds `train.jsonl` (176), `val.jsonl` (24) and `test.jsonl` (24)
  with a stratified 80/10/10 split and a fixed seed. `test.jsonl` is never edited after it is created.
- `python validate_dataset.py glossip_message_classifier` reports no errors.

## 3 sample examples
| input | output |
|---|---|
| Mujhe kal shaam ko haircut ka appointment chahiye. | booking |
| Agar main appointment cancel karun to deposit wapis milega? | cancel_reschedule |
| Worst service ever!! | complaint |
